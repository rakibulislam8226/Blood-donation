package com.example.blood_donate;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class other_details extends AppCompatActivity {
    private EditText editname,editlocation,editthana,edithospital;
    private Button submit;
    private String name,location,thana,hospital;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_other_details);
        editname=findViewById(R.id.ename);
        editlocation=findViewById(R.id.elocation);
        editthana=findViewById(R.id.ethana);
        edithospital=findViewById(R.id.ehospital);
        submit=findViewById(R.id.submit);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendData();
            }
        });
    }
    public void sendData(){
        name=editname.getText().toString().trim();
        location=editlocation.getText().toString().trim();
        thana=editthana.getText().toString().trim();
        hospital=edithospital.getText().toString().trim();

        Intent b = new Intent(other_details.this, confirm.class);
        b.putExtra(confirm.NAME,name);
        b.putExtra(confirm.DISTRICT,location);
        b.putExtra(confirm.THANA,thana);
        b.putExtra(confirm.HOSPITAL,hospital);
        startActivity(b);

    }
}