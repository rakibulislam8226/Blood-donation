package com.example.blood_donate;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class confirm extends AppCompatActivity {
    public static final String NAME="NAME";
    public static final String DISTRICT="DISTRICT";
    public static final String THANA="THANA";
    public static final String HOSPITAL="HOSPITAL";

    private TextView nameText,districtText,thanaText,hospitalText;
    private String name,district,thana,hospital;
    Button b11,btn12;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirm);

        b11=findViewById(R.id.b11);
        btn12=findViewById(R.id.btn12);

        nameText=findViewById(R.id.name);
        districtText=findViewById(R.id.location);
        thanaText=findViewById(R.id.thana);
        hospitalText=findViewById(R.id.hospital);

        Intent i = getIntent();
        name= i.getStringExtra(NAME);
        district= i.getStringExtra(DISTRICT);
        thana= i.getStringExtra(THANA);
        hospital= i.getStringExtra(HOSPITAL);

        nameText.setText("Hello: "+ name);
        districtText.setText("Your District are: "+ district);
        thanaText.setText("Police Station are: "+ thana);
        hospitalText.setText("Nearest Hospital: "+ hospital);

        b11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent b = new Intent(confirm.this, other_details.class);
                startActivity(b);
            }
        });
        btn12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent b = new Intent(confirm.this, thank.class);
                startActivity(b);
            }
        });

    }
}