package com.example.blood_donate;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class bloodadd extends AppCompatActivity {
    EditText edname;
    EditText ehosp;
    Spinner spinner;
    Button submitbtn;
    DatabaseReference bloodaddData;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bloodadd);

        edname=findViewById(R.id.edname);
        ehosp=findViewById(R.id.ehosp);

        spinner=findViewById(R.id.spinner);

        submitbtn=findViewById(R.id.submitbtn);

        bloodaddData= FirebaseDatabase.getInstance().getReference().child("addblood");

        submitbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                insertBlooddata();
            }
        });
    }
    private void insertBlooddata() {
        String name = edname.getText().toString();
        String hospital = ehosp.getText().toString();
        String group = spinner.getSelectedItem().toString();

        addblood addblood = new addblood(name,hospital,group);

        bloodaddData.push().setValue(addblood);
        Toast.makeText(bloodadd.this, "Blood Inserted", Toast.LENGTH_SHORT).show();
    }
}