package com.example.blood_donate;

public class addblood {

    String name,hospital,group;

    public addblood(String name, String hospital, String group) {
        this.name = name;
        this.hospital = hospital;
        this.group = group;
    }

    public String getName() {
        return name;
    }

    public String getHospital() {
        return hospital;
    }

    public String getGroup() {
        return group;
    }
}
